# 微博快速拉黑chrome插件

点进用户主页才能拉黑太麻烦了，所以做了个chrome插件通过在评论区用户名旁生成拉黑按钮，方便快速拉黑。

# 下载   

## git clone


## 下载压缩包

(下载)[http://zhangpengfan.xyz/weibo-block.zip]    

 


